public interface IQuickSubmitComponent
{
}
